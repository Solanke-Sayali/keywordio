from django.shortcuts import render, redirect
from library.models import Admin_Signup
from library.models import Add_Book

def home_page(request):
    return render(request, 'library/homepage.html')


def sign_up(request):

    if request.method == 'POST':
        f_name = request.POST['fname']
        l_name = request.POST['lname']
        u_sername = request.POST['username']
        p_assword = request.POST['password']

        obj = Admin_Signup(fname = f_name, lname = l_name, username = u_sername, password = p_assword)
        obj.save()

        return render(request, 'library/signup.html')

    return render(request, 'library/signup.html')


def userlogin(request, username):
    obj = Admin_Signup(username = username)
    return render(request, 'library/userinfo.html', {'obj': obj})


def admin_list(request):
    data = Admin_Signup.objects.all()
    return render(request, 'library/adminlist.html', {'data': data})


def add_book(request):
    if request.method == 'POST':
        b_name = request.POST['bname']
        b_auther = request.POST['bauther']
        b_code = request.POST['bcode']
        b_price = request.POST['bprice']

        obj = Add_Book(bookname = b_name, bookauther = b_auther, bookcode = b_code, bookprice = b_price)
        obj.save()

        return render(request, 'library/addbook.html')
    
    return render(request, 'library/addbook.html')


def book_list(request):
    book = Add_Book.objects.all()
    return render(request, 'library/booklist.html', {'book': book})


def update_book(request, id):
    obj = Add_Book.objects.get(pk = id)
    if request.method == 'POST':
        obj.bookname = request.POST['bname']
        obj.bookauther = request.POST['bauther']
        obj.bookcode = request.POST['bcode']
        obj.bookprice = request.POST['bprice']
        obj.save()

        return render(request, 'library/updatebook.html')
    return render(request, 'library/updatebook.html', {'obj': obj})


def delete_book(request, id):
    obj = Add_Book.objects.get(pk = id)
    obj.delete()
    return redirect("/library/booklist/")
