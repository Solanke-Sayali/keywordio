from django.db import models

class Admin_Signup(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    def __str__(self):
        return self.fname


class Add_Book(models.Model):
    bookname = models.CharField(max_length=50)
    bookauther = models.CharField(max_length=50)
    bookcode = models.CharField(max_length=50)
    bookprice = models.IntegerField()

    def __str__(self):
        return self.bookname
