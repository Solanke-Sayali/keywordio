from django.urls import path
from library import views

urlpatterns = [
    path('home/', views.home_page),
    path('signup/', views.sign_up),
    path('adminlist/', views.admin_list),
    path('addbook/', views.add_book),
    path('booklist/', views.book_list),
    path('updatebook/<int:id>', views.update_book),
    path('deletebook/<int:id>', views.delete_book),
] 