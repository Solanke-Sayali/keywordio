from django.contrib import admin
from library.models import Admin_Signup
from library.models import Add_Book

admin.site.register(Admin_Signup)
admin.site.register(Add_Book)